﻿namespace Buoi04_Bai_4_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUCLN = new System.Windows.Forms.Button();
            this.btnTBM = new System.Windows.Forms.Button();
            this.btnDemSochan = new System.Windows.Forms.Button();
            this.btnDemSole = new System.Windows.Forms.Button();
            this.btnSNT = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            this.btnSHH = new System.Windows.Forms.Button();
            this.btnMax = new System.Windows.Forms.Button();
            this.btnSum = new System.Windows.Forms.Button();
            this.btnSXTang = new System.Windows.Forms.Button();
            this.btnSXGiam = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnIn = new System.Windows.Forms.Button();
            this.txtNhap = new System.Windows.Forms.RichTextBox();
            this.btnNhap = new System.Windows.Forms.Button();
            this.txtKq = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnUCLN
            // 
            this.btnUCLN.Location = new System.Drawing.Point(12, 216);
            this.btnUCLN.Name = "btnUCLN";
            this.btnUCLN.Size = new System.Drawing.Size(244, 45);
            this.btnUCLN.TabIndex = 34;
            this.btnUCLN.Text = "UCLN 2 Phần Tử Đầu Tiên";
            this.btnUCLN.UseVisualStyleBackColor = true;
            this.btnUCLN.Click += new System.EventHandler(this.btnUCLN_Click);
            // 
            // btnTBM
            // 
            this.btnTBM.Location = new System.Drawing.Point(262, 216);
            this.btnTBM.Name = "btnTBM";
            this.btnTBM.Size = new System.Drawing.Size(195, 45);
            this.btnTBM.TabIndex = 33;
            this.btnTBM.Text = "Trung Bình Mảng";
            this.btnTBM.UseVisualStyleBackColor = true;
            this.btnTBM.Click += new System.EventHandler(this.btnTBM_Click);
            // 
            // btnDemSochan
            // 
            this.btnDemSochan.Location = new System.Drawing.Point(12, 165);
            this.btnDemSochan.Name = "btnDemSochan";
            this.btnDemSochan.Size = new System.Drawing.Size(151, 45);
            this.btnDemSochan.TabIndex = 32;
            this.btnDemSochan.Text = "Đếm Số Chẳn";
            this.btnDemSochan.UseVisualStyleBackColor = true;
            this.btnDemSochan.Click += new System.EventHandler(this.btnDemSochan_Click);
            // 
            // btnDemSole
            // 
            this.btnDemSole.Location = new System.Drawing.Point(169, 165);
            this.btnDemSole.Name = "btnDemSole";
            this.btnDemSole.Size = new System.Drawing.Size(141, 45);
            this.btnDemSole.TabIndex = 31;
            this.btnDemSole.Text = "Đếm Số Lẻ";
            this.btnDemSole.UseVisualStyleBackColor = true;
            this.btnDemSole.Click += new System.EventHandler(this.btnDemSole_Click);
            // 
            // btnSNT
            // 
            this.btnSNT.Location = new System.Drawing.Point(316, 165);
            this.btnSNT.Name = "btnSNT";
            this.btnSNT.Size = new System.Drawing.Size(141, 45);
            this.btnSNT.TabIndex = 30;
            this.btnSNT.Text = "Số Nguyên Tố";
            this.btnSNT.UseVisualStyleBackColor = true;
            this.btnSNT.Click += new System.EventHandler(this.btnSNT_Click);
            // 
            // btnMin
            // 
            this.btnMin.Location = new System.Drawing.Point(463, 216);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(141, 45);
            this.btnMin.TabIndex = 29;
            this.btnMin.Text = "Số Nhỏ Nhất";
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // btnSHH
            // 
            this.btnSHH.Location = new System.Drawing.Point(463, 165);
            this.btnSHH.Name = "btnSHH";
            this.btnSHH.Size = new System.Drawing.Size(141, 45);
            this.btnSHH.TabIndex = 28;
            this.btnSHH.Text = "Số Hoàn Hảo ";
            this.btnSHH.UseVisualStyleBackColor = true;
            this.btnSHH.Click += new System.EventHandler(this.btnSHH_Click);
            // 
            // btnMax
            // 
            this.btnMax.Location = new System.Drawing.Point(610, 216);
            this.btnMax.Name = "btnMax";
            this.btnMax.Size = new System.Drawing.Size(141, 45);
            this.btnMax.TabIndex = 27;
            this.btnMax.Text = "Số Lớn Nhất";
            this.btnMax.UseVisualStyleBackColor = true;
            this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
            // 
            // btnSum
            // 
            this.btnSum.Location = new System.Drawing.Point(610, 165);
            this.btnSum.Name = "btnSum";
            this.btnSum.Size = new System.Drawing.Size(141, 45);
            this.btnSum.TabIndex = 26;
            this.btnSum.Text = "Tổng Mảng";
            this.btnSum.UseVisualStyleBackColor = true;
            this.btnSum.Click += new System.EventHandler(this.btnSum_Click);
            // 
            // btnSXTang
            // 
            this.btnSXTang.Location = new System.Drawing.Point(610, 114);
            this.btnSXTang.Name = "btnSXTang";
            this.btnSXTang.Size = new System.Drawing.Size(141, 45);
            this.btnSXTang.TabIndex = 25;
            this.btnSXTang.Text = "Sắp Xếp Tăng";
            this.btnSXTang.UseVisualStyleBackColor = true;
            this.btnSXTang.Click += new System.EventHandler(this.btnSXTang_Click);
            // 
            // btnSXGiam
            // 
            this.btnSXGiam.Location = new System.Drawing.Point(610, 63);
            this.btnSXGiam.Name = "btnSXGiam";
            this.btnSXGiam.Size = new System.Drawing.Size(141, 45);
            this.btnSXGiam.TabIndex = 24;
            this.btnSXGiam.Text = "Sắp Xếp Giảm ";
            this.btnSXGiam.UseVisualStyleBackColor = true;
            this.btnSXGiam.Click += new System.EventHandler(this.btnSXGiam_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(610, 12);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(141, 45);
            this.btnThoat.TabIndex = 23;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(463, 12);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(141, 45);
            this.btnXoa.TabIndex = 22;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnIn
            // 
            this.btnIn.Location = new System.Drawing.Point(316, 12);
            this.btnIn.Name = "btnIn";
            this.btnIn.Size = new System.Drawing.Size(141, 45);
            this.btnIn.TabIndex = 21;
            this.btnIn.Text = "In Mảng ";
            this.btnIn.UseVisualStyleBackColor = true;
            this.btnIn.Click += new System.EventHandler(this.btnIn_Click);
            // 
            // txtNhap
            // 
            this.txtNhap.Location = new System.Drawing.Point(169, 12);
            this.txtNhap.Name = "txtNhap";
            this.txtNhap.Size = new System.Drawing.Size(141, 45);
            this.txtNhap.TabIndex = 20;
            this.txtNhap.Text = "";
            // 
            // btnNhap
            // 
            this.btnNhap.Location = new System.Drawing.Point(12, 12);
            this.btnNhap.Name = "btnNhap";
            this.btnNhap.Size = new System.Drawing.Size(151, 45);
            this.btnNhap.TabIndex = 19;
            this.btnNhap.Text = "Nhập 1 phần tử";
            this.btnNhap.UseVisualStyleBackColor = true;
            this.btnNhap.Click += new System.EventHandler(this.btnNhap_Click);
            // 
            // txtKq
            // 
            this.txtKq.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.txtKq.ForeColor = System.Drawing.Color.White;
            this.txtKq.Location = new System.Drawing.Point(12, 63);
            this.txtKq.Name = "txtKq";
            this.txtKq.ReadOnly = true;
            this.txtKq.Size = new System.Drawing.Size(592, 96);
            this.txtKq.TabIndex = 18;
            this.txtKq.TabStop = false;
            this.txtKq.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 274);
            this.Controls.Add(this.btnUCLN);
            this.Controls.Add(this.btnTBM);
            this.Controls.Add(this.btnDemSochan);
            this.Controls.Add(this.btnDemSole);
            this.Controls.Add(this.btnSNT);
            this.Controls.Add(this.btnMin);
            this.Controls.Add(this.btnSHH);
            this.Controls.Add(this.btnMax);
            this.Controls.Add(this.btnSum);
            this.Controls.Add(this.btnSXTang);
            this.Controls.Add(this.btnSXGiam);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnIn);
            this.Controls.Add(this.txtNhap);
            this.Controls.Add(this.btnNhap);
            this.Controls.Add(this.txtKq);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnUCLN;
        private System.Windows.Forms.Button btnTBM;
        private System.Windows.Forms.Button btnDemSochan;
        private System.Windows.Forms.Button btnDemSole;
        private System.Windows.Forms.Button btnSNT;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.Button btnSHH;
        private System.Windows.Forms.Button btnMax;
        private System.Windows.Forms.Button btnSum;
        private System.Windows.Forms.Button btnSXTang;
        private System.Windows.Forms.Button btnSXGiam;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnIn;
        private System.Windows.Forms.RichTextBox txtNhap;
        private System.Windows.Forms.Button btnNhap;
        private System.Windows.Forms.RichTextBox txtKq;
    }
}

